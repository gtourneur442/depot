var searchData=
[
  ['getname',['getName',['../classCycliste.html#a0c46061d327f2c76830904fb83a370a5',1,'Cycliste']]],
  ['gettime',['getTime',['../classCycliste.html#a9cef69b7cb1050fea25da277eea06940',1,'Cycliste']]]
];
