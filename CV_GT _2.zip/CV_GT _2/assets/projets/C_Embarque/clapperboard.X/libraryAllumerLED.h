#ifndef LIBRARY_ALLUMER_LED_H    /* Guard against multiple inclusion */
#define LIBRARY_ALLUMER_LED_H

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <sys/attribs.h>

void allumerLED(char value);
void allumerLED2(int value);
int boolean();

#endif

