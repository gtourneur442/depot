
#ifndef CHANGER_CHIFFRE_H    /* Guard against multiple inclusion */
#define CHANGER_CHIFFRE_H

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <sys/attribs.h>

void initdDigit();
void displayDigit(char digitNumber,int value);
void minSecondes(int number);

#endif

