
#ifndef TIMER_H    /* Guard against multiple inclusion */
#define TIMER_H

#include "interruptTimer.h"

//void initTimer(void);
void initTimer2(void);
void initTimer3(void);

#endif /* TIMER_H */
