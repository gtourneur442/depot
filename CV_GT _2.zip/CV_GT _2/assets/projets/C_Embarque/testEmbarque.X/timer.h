
#ifndef TIMER_H    /* Guard against multiple inclusion */
#define TIMER_H

#include "interruptTimer.h"

void initTimer(void);

#endif /* TIMER_H */
