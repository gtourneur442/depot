
#ifndef REVERSE_LED_H    /* Guard against multiple inclusion */
#define REVERSE_LED_H

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <sys/attribs.h>

void initButton();
//unsigned char valueFromSwitch();
void ReverseLED();

#endif /* REVERSE_LED_H */

