#ifndef GET_SWITCH_H    /* Guard against multiple inclusion */
#define GET_SWITCH_H

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <sys/attribs.h>

void initSw();
char getSwitch(char swNumber);

#endif

